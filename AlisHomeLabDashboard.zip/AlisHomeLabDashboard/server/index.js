require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

const { getProxmoxStatus } = require("./lib/proxmox");
const { getTrueNASStatus } = require("./lib/truenas");
const { getSwitchStatus } = require("./lib/switch");

const app = express();
const PORT = process.env.PORT || 8080;
const POLL_INTERVAL_MS = Number(process.env.POLL_INTERVAL_MS || 10000);

app.use(cors());

let cache = {
  updatedAt: null,
  proxmox: { configured: false },
  truenas: { configured: false },
  switch: { configured: false },
};

async function refresh() {
  const [proxmox, truenas, sw] = await Promise.all([
    getProxmoxStatus().catch((e) => ({ configured: true, online: false, error: e.message })),
    getTrueNASStatus().catch((e) => ({ configured: true, online: false, error: e.message })),
    getSwitchStatus().catch((e) => ({ configured: true, online: false, error: e.message })),
  ]);
  cache = { updatedAt: new Date().toISOString(), proxmox, truenas, switch: sw };
}

app.get("/api/status", (req, res) => res.json(cache));
app.get("/api/proxmox", (req, res) => res.json(cache.proxmox));
app.get("/api/truenas", (req, res) => res.json(cache.truenas));
app.get("/api/switch", (req, res) => res.json(cache.switch));
app.get("/api/health", (req, res) => res.json({ ok: true, updatedAt: cache.updatedAt }));

app.use(express.static(path.join(__dirname, "..", "public")));

app.listen(PORT, () => {
  console.log(`Ali's Homelab Dashboard listening on :${PORT}`);
  refresh();
  setInterval(refresh, POLL_INTERVAL_MS);
});
