# Ali's Homelab Dashboard

A live status dashboard for a Proxmox + TrueNAS + Cisco switch homelab,
styled after a HUD/JARVIS interface. Ships as a single Docker container: a
small Node/Express backend polls your gear and serves a static frontend
that renders it.

```
AlisHomeLabDashboard/
├── server/           Express API (Proxmox, TrueNAS, SNMP switch polling)
├── public/           Frontend (vanilla HTML/CSS/JS, no build step)
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── .gitignore        <- keeps .env and node_modules out of git
```

Any panel you don't configure just shows "not configured" — add sources
one at a time.

## Before you commit anything

**`.env` holds live credentials (Proxmox API token, TrueNAS API key, SNMP
community string) and must never be committed.** The included
`.gitignore` already excludes it — don't remove that line, and don't
commit zipped copies of the project either (also excluded, `*.zip`), since
a zip's contents aren't inspected by `.gitignore` and secrets can end up
inside one without you noticing.

Commit real source files, not archives:
```bash
git add server public Dockerfile docker-compose.yml .env.example .gitignore README.md
git commit -m "Initial commit"
```

## 1. Set up credentials

```bash
cp .env.example .env
nano .env
```

### Proxmox
1. Datacenter → Permissions → API Tokens → Add. User `root@pam`, Token ID
   `dashboard`. Leave "Privilege Separation" checked.
2. Datacenter → Permissions → Add → **API Token Permission** (not User
   Permission) → Path `/`, API Token `root@pam!dashboard`, Role
   `PVEAuditor`, Propagate = yes.
3. Copy the token secret into `PROXMOX_TOKEN_SECRET`.
4. `PROXMOX_HOST` is `ip:8006`. Leave `PROXMOX_VERIFY_SSL=false` unless
   you've installed a real (non-self-signed) cert.

### TrueNAS SCALE
1. Top-right user icon → API Keys → Add. Copy the key immediately — it's
   shown only once.
2. Set `TRUENAS_HOST` and `TRUENAS_API_KEY`.

### Switch (SNMP)
```
configure terminal
snmp-server community <your-string> RO
end
write memory
```
Use a real (non-`public`) community string. Set `SWITCH_HOST` and
`SWITCH_SNMP_COMMUNITY` to match.

### Guest quick-links (optional)
`GUEST_LINKS` maps a guest's Proxmox name to a URL, so clicking its name
in the accordion opens that service in a new tab:
```
GUEST_LINKS=Pihole=http://192.168.1.99/admin;Nginx=http://192.168.1.101:81
```
Semicolon-separated `Name=URL` pairs, matched case-insensitively.

## 2. Run it

```bash
docker compose up -d --build
```

Then open `http://<host>:8080`.

## 3. After any code change

Backend or frontend files changed → rebuild:
```bash
docker compose up -d --build
```

Only `.env` changed (no code) → restart is enough, no rebuild:
```bash
docker compose up -d
```

Always verify a rebuild actually picked up your change before assuming
it worked:
```bash
docker compose logs --since 1m | tail -20
```
and hard-refresh the browser (`Ctrl+Shift+R` / `Cmd+Shift+R`) since it
caches JS/CSS aggressively.

## Notes / scope decisions

- **Read-only by design.** Nothing in this dashboard can start/stop VMs,
  containers, or touch switch config — it only reads status. Proxmox
  token is `PVEAuditor` (read-only), SNMP community is `RO`.
- **Polling, not push.** The backend polls all sources on one shared
  interval (`POLL_INTERVAL_MS`, default 10s) and caches the result.
- **Guest links point at LAN-only addresses.** They'll only work from
  devices on your home network (or over Tailscale, once set up) — not
  from outside it.
