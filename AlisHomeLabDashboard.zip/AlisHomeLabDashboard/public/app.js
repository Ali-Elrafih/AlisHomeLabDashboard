const REFRESH_MS = 10000;

// Holds the most recent /api/status payload so the accordion can render
// on click without waiting for the next poll, and keeps its open/closed
// state stable across polls.
let lastState = null;
let pveExpanded = false;

function fmtBytes(b) {
  if (!b && b !== 0) return "--";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0, n = b;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(1)} ${units[i]}`;
}

function fmtUptime(sec) {
  if (!sec && sec !== 0) return "--";
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

function barClass(pct) {
  if (pct >= 90) return "bad";
  if (pct >= 70) return "warn";
  return "";
}

function metricRow(label, valueText, pct) {
  return `
    <div class="metric">
      <div class="metric-row"><span>${label}</span><span class="val">${valueText}</span></div>
      <div class="bar-track"><div class="bar-fill ${barClass(pct)}" style="width:${Math.min(pct,100)}%"></div></div>
    </div>`;
}

function renderProxmox(pve) {
  const tag = document.getElementById("pve-tag");
  const body = document.getElementById("pve-body");
  if (!pve.configured) { body.innerHTML = `<div class="empty">Set PROXMOX_HOST / token in .env</div>`; tag.textContent = "OFFLINE"; return; }
  if (!pve.online) { body.innerHTML = `<div class="empty">Connection failed: ${pve.error || "unreachable"}</div>`; tag.textContent = "ERROR"; return; }

  tag.textContent = `${pve.runningGuests}/${pve.totalGuests} RUNNING`;
  let html = "";
  (pve.nodes || []).forEach((n) => {
    if (n.error) { html += `<div class="empty">${n.name}: unreachable</div>`; return; }
    const cpuPct = n.cpu;
    const memPct = n.memTotal ? Math.round((n.memUsed / n.memTotal) * 100) : 0;
    html += `<div class="subhead">${n.name.toUpperCase()} &middot; up ${fmtUptime(n.uptime)}</div>`;
    html += metricRow("CPU LOAD", `${cpuPct}%`, cpuPct);
    html += metricRow("MEMORY", `${fmtBytes(n.memUsed)} / ${fmtBytes(n.memTotal)}`, memPct);
  });
  body.innerHTML = html || `<div class="empty">No nodes found</div>`;
}

// Renders the per-guest (LXC/VM) accordion under the Proxmox Nodes panel.
// Uses pve.guests, which is already fetched via /cluster/resources?type=vm
// on the backend — no separate /nodes/{node}/lxc or /nodes/{node}/qemu
// calls are made, since that data is already in this payload.
function renderProxmoxGuests(pve) {
  const container = document.getElementById("pve-guests");
  if (!pve || !pve.configured || !pve.online) {
    container.innerHTML = `<div class="empty">No guest data available</div>`;
    return;
  }

  const guests = pve.guests || [];
  if (!guests.length) {
    container.innerHTML = `<div class="empty">No VMs or containers found</div>`;
    return;
  }

  // Group by node, since a cluster can have more than one.
  const byNode = {};
  guests.forEach((g) => {
    if (!byNode[g.node]) byNode[g.node] = [];
    byNode[g.node].push(g);
  });

  let html = "";
  Object.keys(byNode).sort().forEach((nodeName) => {
    html += `<div class="guest-node-label">${nodeName.toUpperCase()}</div>`;
    byNode[nodeName]
      .sort((a, b) => a.id - b.id)
      .forEach((g) => {
        const up = g.status === "running";
        const nameHtml = g.link
          ? `<a class="guest-name guest-link" href="${g.link}" target="_blank" rel="noopener noreferrer" title="Open ${g.name}">${g.name}</a>`
          : `<span class="guest-name" title="${g.name}">${g.name}</span>`;
        html += `
          <div class="guest-row">
            <span class="dot ${up ? "dot-ok" : "dot-bad"}"></span>
            ${nameHtml}
            <span class="guest-type">${g.type === "lxc" ? "LXC" : "VM"}</span>
            <span class="guest-status ${up ? "up" : ""}">${g.status.toUpperCase()}</span>
          </div>`;
      });
  });

  container.innerHTML = html;
}

function setupProxmoxAccordion() {
  const toggle = document.getElementById("pve-toggle");
  const accordion = document.getElementById("pve-accordion");
  const chevron = document.getElementById("pve-chevron");

  toggle.addEventListener("click", () => {
    pveExpanded = !pveExpanded;
    accordion.classList.toggle("open", pveExpanded);
    chevron.classList.toggle("open", pveExpanded);
    // Render immediately from whatever we already have cached, rather
    // than waiting for the next poll cycle.
    if (pveExpanded && lastState) renderProxmoxGuests(lastState.proxmox);
  });
}

function renderTrueNAS(nas) {
  const tag = document.getElementById("nas-tag");
  const body = document.getElementById("nas-body");
  if (!nas.configured) { body.innerHTML = `<div class="empty">Set TRUENAS_HOST / API key in .env</div>`; tag.textContent = "OFFLINE"; return; }
  if (!nas.online) { body.innerHTML = `<div class="empty">Connection failed: ${nas.error || "unreachable"}</div>`; tag.textContent = "ERROR"; return; }

  tag.textContent = "ONLINE";
  let html = `<div class="subhead">${(nas.hostname || "TRUENAS").toUpperCase()} &middot; up ${fmtUptime(nas.uptimeSeconds)}</div>`;

  (nas.pools || []).forEach((p) => {
    const cap = (nas.capacity || []).find((c) => c.name === p.name);
    const pct = cap && (cap.usedBytes + cap.availableBytes) > 0
      ? Math.round((cap.usedBytes / (cap.usedBytes + cap.availableBytes)) * 100)
      : 0;
    const statusOk = p.status === "ONLINE";
    html += `
      <div class="metric">
        <div class="metric-row">
          <span><span class="dot ${statusOk ? "dot-ok" : "dot-bad"}" style="margin-right:6px;"></span>${p.name}</span>
          <span class="val">${p.status}</span>
        </div>
        ${cap ? `<div class="bar-track"><div class="bar-fill ${barClass(pct)}" style="width:${pct}%"></div></div>
        <div class="metric-row" style="margin-top:4px;"><span>${fmtBytes(cap.usedBytes)} used</span><span>${fmtBytes(cap.availableBytes)} free</span></div>` : ""}
      </div>`;
  });

  body.innerHTML = html;
}

function renderSwitch(sw) {
  const tag = document.getElementById("sw-tag");
  const body = document.getElementById("sw-body");
  if (!sw.configured) { body.innerHTML = `<div class="empty">Set SWITCH_HOST / SNMP community in .env</div>`; tag.textContent = "OFFLINE"; return; }
  if (!sw.online) { body.innerHTML = `<div class="empty">SNMP unreachable: ${sw.error || "no response"}</div>`; tag.textContent = "ERROR"; return; }

  tag.textContent = `${sw.portsUp}/${sw.totalPorts} UP`;
  let html = `<div class="subhead">${(sw.sysName || "SWITCH").toUpperCase()} &middot; up ${fmtUptime(sw.uptimeSeconds)}</div>`;
  html += `<div class="port-grid">`;
  (sw.ports || []).forEach((p) => {
    html += `<div class="port-dot ${p.operStatus === 1 ? "up" : "down"}" title="${p.descr}"></div>`;
  });
  html += `</div>`;
  body.innerHTML = html;
}

function renderSummary(state) {
  const body = document.getElementById("summary-body");
  const pve = state.proxmox, nas = state.truenas, sw = state.switch;

  const nodeCount = pve.configured && pve.online ? (pve.nodes || []).length : 0;
  const guestStr = pve.configured && pve.online ? `${pve.runningGuests}/${pve.totalGuests}` : "--";
  const poolCount = nas.configured && nas.online ? (nas.pools || []).length : 0;
  const portStr = sw.configured && sw.online ? `${sw.portsUp}/${sw.totalPorts}` : "--";

  body.innerHTML = `
    <div class="stat-grid">
      <div class="stat-box"><div class="n">${nodeCount}</div><div class="lbl">PVE NODES</div></div>
      <div class="stat-box"><div class="n">${guestStr}</div><div class="lbl">GUESTS RUNNING</div></div>
      <div class="stat-box"><div class="n">${poolCount}</div><div class="lbl">ZFS POOLS</div></div>
      <div class="stat-box"><div class="n">${portStr}</div><div class="lbl">SWITCH PORTS</div></div>
    </div>
  `;
}

function renderEventLog(state) {
  const body = document.getElementById("log-body");
  const events = [];

  if (state.proxmox.online) {
    (state.proxmox.recentTasks || []).forEach((t) => {
      events.push({
        time: t.startTime ? new Date(t.startTime * 1000) : new Date(),
        text: `[PVE:${t.node}] ${t.type} \u2014 ${t.status}`,
        level: t.status === "OK" || t.status === "running" ? "ok" : "warn",
      });
    });
  }
  if (state.truenas.online) {
    (state.truenas.alerts || []).forEach((a) => {
      events.push({
        time: a.datetime ? new Date(a.datetime * 1000) : new Date(),
        text: `[NAS] ${a.text}`,
        level: a.level === "CRITICAL" || a.level === "ERROR" ? "bad" : "warn",
      });
    });
  }

  events.sort((a, b) => b.time - a.time);

  if (!events.length) { body.innerHTML = `<div class="empty">No recent events</div>`; return; }

  body.innerHTML = events.slice(0, 12).map((e) => `
    <div class="log-line ${e.level === "bad" ? "bad" : e.level === "warn" ? "warn" : ""}">
      <span class="t">[${e.time.toLocaleTimeString()}]</span>${e.text}
    </div>`).join("");
}

function renderRawAlerts(state) {
  const body = document.getElementById("raw-body");
  const lines = [];
  ["proxmox", "truenas", "switch"].forEach((k) => {
    const s = state[k];
    if (s.configured && !s.online) lines.push(`<div class="log-line bad">[${k.toUpperCase()}] ${s.error || "offline"}</div>`);
    if (!s.configured) lines.push(`<div class="log-line">[${k.toUpperCase()}] not configured</div>`);
  });
  body.innerHTML = lines.length ? lines.join("") : `<div class="empty">All systems reporting normally</div>`;
}

function renderCore(state) {
  const anyConfigured = [state.proxmox, state.truenas, state.switch].some((s) => s.configured);
  const anyError = [state.proxmox, state.truenas, state.switch].some((s) => s.configured && !s.online);
  const dot = document.getElementById("global-dot");
  const statusText = document.getElementById("global-status");
  const coreLabel = document.getElementById("core-label");
  const coreSub = document.getElementById("core-sub");

  if (!anyConfigured) {
    dot.className = "dot dot-warn"; statusText.textContent = "NOT CONFIGURED";
    coreLabel.textContent = "IDLE"; coreSub.textContent = "no sources set";
    return;
  }
  if (anyError) {
    dot.className = "dot dot-bad"; statusText.textContent = "DEGRADED";
    coreLabel.textContent = "DEGRADED"; coreSub.textContent = "check alerts panel";
    return;
  }
  dot.className = "dot dot-ok"; statusText.textContent = "OPTIMAL";
  coreLabel.textContent = "CORE"; coreSub.textContent = "ACTIVE";
}

function updateClock() {
  document.getElementById("clock").textContent = new Date().toLocaleTimeString();
}

async function refresh() {
  try {
    const res = await fetch("/api/status");
    const state = await res.json();
    lastState = state;

    renderProxmox(state.proxmox);
    if (pveExpanded) renderProxmoxGuests(state.proxmox);
    renderTrueNAS(state.truenas);
    renderSwitch(state.switch);
    renderSummary(state);
    renderEventLog(state);
    renderRawAlerts(state);
    renderCore(state);
    document.getElementById("ticker-text").textContent =
      `Last sync ${new Date(state.updatedAt).toLocaleTimeString()} \u2014 next in ${REFRESH_MS / 1000}s`;
  } catch (err) {
    document.getElementById("ticker-text").textContent = `Sync failed: ${err.message}`;
  }
}

setupProxmoxAccordion();
updateClock();
setInterval(updateClock, 1000);
refresh();
setInterval(refresh, REFRESH_MS);
